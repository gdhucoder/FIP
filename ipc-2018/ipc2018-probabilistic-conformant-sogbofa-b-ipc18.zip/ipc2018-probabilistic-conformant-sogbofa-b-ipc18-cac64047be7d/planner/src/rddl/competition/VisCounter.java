package rddl.competition;


public class VisCounter{
	public double randomTime = 0;
	public double randomInTotal = 0;
	public double updatesInTotal = 0;
	public double depthInTotal = 0;
	public double updateTime = 0;
	public double SeenInTotal = 0;
	public double SeenTime = 0;
	public double depthTime = 0;
	public double sizeTime = 0;
	public double sizeInTotal = 0;
	VisCounter(){
		randomInTotal = 0;
		randomTime = 0;
		updatesInTotal = 0;
		updateTime = 0;
		SeenInTotal = 0;
		SeenTime = 0;
		depthInTotal = 0;
		depthTime = 0;
		sizeTime = 0;
		sizeInTotal = 0;
	}
}
