package rddl;

public class Global {
	static public boolean ifLift = true;
	static public boolean ifRecordLift = true;
}
